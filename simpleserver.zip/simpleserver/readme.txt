SIMPLESERVER - MY TEST TASK

This was my first trial project that I developed on Django. This was my first trial project that I developed on Django. It is a simple web server that allows you to run Linux OS shell commands in a browser and receive the result of the command in text/plain format.
