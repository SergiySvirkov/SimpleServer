#!/usr/bin/python3

import cgi, cgitb

form = cgi.FieldStorage()

cmd = form.getvalue('cmd')

print ("Content-type:text/html")
print()
print ("<html>")
print ("<head>")
print ("<title>Output Shell Command</title>")
print ("</head>")
print ("</html>")
